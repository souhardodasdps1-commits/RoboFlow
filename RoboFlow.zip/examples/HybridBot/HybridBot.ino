#include <RoboFlow.h>

Robot bot;

void setup() {
  Serial.begin(9600);

  bot.addUltrasonic(8, 9);
  bot.addBluetooth(Serial);
  bot.addMotors(5, 6, 10, 11);

  bot.setMode(HYBRID);

  bot.when("obstacle < 20", AUTONOMOUS, [](){
    bot.stop();
    bot.turnLeft();
  });

  bot.when("bluetooth == 'F'", MANUAL, [](){
    bot.forward(180);
  });

  bot.when("bluetooth == 'B'", MANUAL, [](){
    bot.turnRight();
  });

  bot.when("bluetooth == 'S'", MANUAL, [](){
    bot.stop();
  });
}

void loop() {
  bot.run();
}
